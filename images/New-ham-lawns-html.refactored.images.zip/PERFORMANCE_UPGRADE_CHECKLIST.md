# Hamilton Lawns — Performance Upgrade Checklist

## What We Fixed

**BEFORE:** Pages loading 14-25MB of unoptimized PNG images  
**AFTER:** Same pages loading 1.6-2MB with WebP + lazy loading  
**SAVINGS:** 93% reduction in page weight

---

## Files to Upload to GitHub

### 1. Replace HTML Files
Upload these optimized HTML files to your repo root:
- ✅ `index.html`
- ✅ `services.html`
- ✅ `contact.html`
- ✅ `sitemap.xml`

### 2. Add WebP Images to /images/ Folder
Upload these NEW WebP files to your `/images/` directory:
- ✅ `b4-after-1.webp` (187KB — was 2.0MB PNG)
- ✅ `b4-after-2.webp` (101KB — was 1.8MB PNG)
- ✅ `b4-after-3.webp` (200KB — was 2.1MB PNG)
- ✅ `b4-after-4.webp` (135KB — was 1.9MB PNG)
- ✅ `b4-after-5.webp` (87KB — was 2.0MB PNG)
- ✅ `b4-after-6.webp` (268KB — was 2.2MB PNG)
- ✅ `b4-after-7.webp` (170KB — was 1.8MB PNG)
- ✅ `exterior-home-wash.webp` (69KB — was 66KB PNG)
- ✅ `Google-Ads-Offer-Media.webp` (407KB — was 6.6MB PNG)

**DO NOT DELETE THE .PNG FILES** — they're the fallback for older browsers.

### 3. Remove _redirects File (Optional)
- Delete `_redirects` file OR leave it empty
- This removes redirect errors in Google Search Console

---

## Git Commands

```bash
# 1. Add all optimized files
git add index.html services.html contact.html sitemap.xml
git add images/*.webp

# 2. Commit with message
git commit -m "Performance upgrade: WebP images + lazy loading (93% reduction)"

# 3. Push to GitHub
git push origin main
```

---

## After Deploy (Wait 2-3 minutes for Netlify)

### 1. Test Pages Load
- https://hamiltonlawns.co.nz
- https://hamiltonlawns.co.nz/services
- https://hamiltonlawns.co.nz/contact
- https://hamiltonlawns.co.nz/promo-offer

### 2. Run PageSpeed Test
- Go to: https://pagespeed.web.dev/
- Test: https://hamiltonlawns.co.nz
- **Expected Mobile Score: 80-90+** (was ~30-40 before)

### 3. Submit Sitemap in Search Console
- Go to: https://search.google.com/search-console
- Click "Sitemaps"
- Submit: `sitemap.xml`

### 4. Request Indexing for Key Pages
Use URL Inspection tool for:
- https://hamiltonlawns.co.nz
- https://hamiltonlawns.co.nz/promo-offer
- https://hamiltonlawns.co.nz/services
- https://hamiltonlawns.co.nz/contact

---

## Expected Results

**PageSpeed Insights:**
- Mobile: 80-90+ (up from ~30-40)
- Desktop: 90-95+ (up from ~60-70)
- Largest Contentful Paint (LCP): <2.5s (was 5-8s)
- Total Blocking Time: <200ms (was 500ms+)

**Search Console (7 days):**
- "Not indexed" errors → 0
- Indexed pages → 7+

**Google Ads:**
- Landing page speed improved
- Quality Score should increase (lower CPC)

---

## What Changed Technically

1. **Image Format:** PNG → WebP (90% smaller)
2. **Lazy Loading:** Images load only when scrolled into view
3. **Picture Tags:** WebP with PNG fallback for old browsers
4. **Sitemap:** Added promo-offer page
5. **Redirects:** Removed problematic old domain redirect

---

## Troubleshooting

**Images not showing?**
- Check WebP files uploaded to `/images/` folder correctly
- Verify filenames match exactly (case-sensitive)

**Still slow?**
- Clear browser cache (Ctrl+Shift+R)
- Wait 5 minutes for Netlify CDN to update

**Search Console still showing errors?**
- Wait 48 hours for Google to recrawl
- Manually request indexing for each URL

---

**Last updated:** 13 April 2026  
**Performance by:** Kowhai  
**Client:** Hamilton Lawns
